let Discord = require('discord.js')
let db = require('quick.db')
const Kicks = require('../.././models/kicks.js')
const Warns = require('../.././models/warnings.js')


module.exports = {
  name: "removewarn",
  aliases: [],
  category: "Moderation",
  description: "Removes a moderation log from a user",
  guildOnly: true,
  usage: "<id>",
  run: async (client, message, args) => {
    const user = args[0]
    let id = args[1]
    id--;
    Warns.findOne(
          {guildID: message.guild.id, userID: user}, 
        async (err, data) => {
          if (err) console.log(err)
            await data.Warns.splice(data.Warns.indexOf(data.Warns[id]), 1)
            data.save()
        })
  }
}
